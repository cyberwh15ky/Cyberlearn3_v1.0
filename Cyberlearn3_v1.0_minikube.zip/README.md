# Cyberlearn3 v1.0 - Minikube (Docker driver) Deployment

此 repo 為 Cyberlearn3 v1.0 的最終整合版（Minikube Docker driver）。  
包含 A–H：Backend, Frontend, Mobile, Keycloak realm, Kubernetes manifests, Payments placeholders, AI endpoint, CI。

Quick start (Minikube Docker):
1. minikube start --driver=docker --cpus=4 --memory=8192
2. minikube addons enable ingress
3. eval $(minikube docker-env)
4. docker build -t cyberlearn/backend:local ./backend
   docker build -t cyberlearn/frontend:local ./frontend
   docker build -t cyberlearn/keycloak:local ./keycloak
5. kubectl apply -f k8s/
6. echo "$(minikube ip) frontend.cyberlearn.local auth.cyberlearn.local" | sudo tee -a /etc/hosts

詳見 INSTALL_MINIKUBE_DOCKER.md
