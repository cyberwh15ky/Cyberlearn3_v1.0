const express = require('express');
const bodyParser = require('body-parser');
const cors = require('cors');
const {v4: uuidv4} = require('uuid');
const axios = require('axios');

const app = express();
app.use(cors());
app.use(bodyParser.json());

/* In-memory demo stores -- replace with PostgreSQL/Redis in production */
const products = {
  p1: {id:'p1', name:'Sample Product A', likes:0, price: 100},
  p2: {id:'p2', name:'Sample Product B', likes:0, price: 200},
};
const users = {};
const carts = {};

app.get('/api/health', (req,res)=>res.json({ok:true}));
app.get('/api/products', (req,res)=>res.json(Object.values(products)));

app.post('/api/products/:id/like', (req,res)=>{
  const id = req.params.id;
  if (!products[id]) return res.status(404).json({error:'not found'});
  products[id].likes++;
  return res.json({ok:true, likes: products[id].likes});
});

app.post('/api/cart/add', (req,res)=>{
  const user = req.header('x-user-id') || 'guest';
  if (!carts[user]) carts[user] = [];
  carts[user].push(req.body);
  return res.json({ok:true, cart:carts[user]});
});

app.post('/api/checkout/create', (req,res)=>{
  // Placeholder - create order and return payment_url
  const orderId = uuidv4();
  return res.json({ok:true, orderId, payment_url: 'https://example.pay/' + orderId});
});

app.post('/api/ai/query', (req,res)=>{
  const q = req.body.q || '';
  const banned = ['bomb','illegal','hack','exploit'];
  for (const b of banned) if (q.toLowerCase().includes(b)) return res.status(400).json({error:'query not allowed'});
  return res.json({ok:true, answer: 'Demo AI suggestion for: ' + q});
});

const port = process.env.PORT || 4000;
app.listen(port, ()=>console.log('Backend listening on', port));