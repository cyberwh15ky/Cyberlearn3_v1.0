Payments:
- Stripe: recommended for credit cards. Use Stripe Checkout or Payment Intent.
- Alipay / PayMe / FPS: need merchant onboarding with local providers. Implement payment adapter in backend.

Backup:
- For production use Commvault or Velero + object storage for PV backups.

Palo Alto:
- Use CN-Series or next-gen firewall for L7 policies.

Security:
- Keep secrets in Vault / sealed-secrets.
- Do not store card data on your servers unless PCI compliant.
